const express = require("express");
const cors = require("cors");
const axios= require("axios")

const app = express();
app.use(express.json());
app.use(cors({ origin: true }));

app.post("/authenticate", async (req, res) => {
const { username } = req.body;
try {
    const r = await axios.put(
      "https://api.chatengine.io/users/",
      { username: username, secret: username, first_name: username },
      { headers: { "Private-Key": "3bab0bcd-8c29-4cd2-a0c3-84cdef23eb0e" } }
    );
    return res.status(r.status).json(r.data);
  } catch (e) {
    if (e.response) {
      return res.status(e.response.status).json(e.response.data);
    } else if (e.request) {
      return res.status(500).json({ message: 'No response received from the server' });
    } else {
      console.error('Error message:', e.message);
      return res.status(500).json({ message: 'Error setting up the request', error: e.message });
    }
  }
  
});
    
  
  
  


app.listen(3001);